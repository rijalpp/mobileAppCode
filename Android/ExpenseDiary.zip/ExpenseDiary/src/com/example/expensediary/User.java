package com.example.expensediary;

public class User {
	private Integer userID;
	private String email;
	private String password;
	private String fullName;
	private String recordMode;
	
	//GETTER AND SETTER
	public Integer getUserID() {
		return userID ;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getRecordMode() {
		return recordMode;
	}
	
	public void setRecordMode(String recordMode) {
		this.recordMode = recordMode;
	}
	
	//METHODS
	public int RegisterUser(User user)
	{
		return 0;
	}
	
	public int UpdateUser(User user)
	{
		return 0;
	}
	
	public User SelectUser(String email)
	{
		return this;
	}
	
	
}
